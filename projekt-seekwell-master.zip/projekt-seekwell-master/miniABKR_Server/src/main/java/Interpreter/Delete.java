package Interpreter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Delete implements Command {
    private String name;
    private boolean isEqual;

    private String value;

    public Delete(String name, boolean isEqual, String value) {
        this.name = name;
        this.isEqual = isEqual;
        this.value = value;
    }

    /**
     * Returns the command type as a String
     *
     * @return command type
     */
    @Override
    public String getType() {
        return "DELETE";
    }

    /**
     * Returns the provided table name
     *
     * @return table name
     */
    @Override
    public String getName() {
        return name;
    }

    public static Delete check(String expr) {
        // Nev - a tabla amibol torlunk
        Pattern deleteRegex = Pattern.compile("^DELETE\\s+[a-z][a-z0-9_]*\\s*WHERE\\s+[a-z][a-z0-9_]*\\s+(=|!=)\\s+[a-z0-9][a-z0-9_.,\\-]*$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = deleteRegex.matcher(expr);
        if (!matcher.find()) {
            return null;
        }
        String exprAux = expr.replaceAll("\\s+", " ");
        boolean isEq;
        if (exprAux.contains("!")) {
            isEq = false;
        } else {
            isEq = true;
        }
        String val = exprAux.substring(exprAux.lastIndexOf(" ") + 1);
        return new Delete(exprAux.substring(exprAux.indexOf(" ") + 1, exprAux.indexOf("WHERE") - 1), isEq, val);
    }

    public boolean isEqual() {
        return isEqual;
    }

    public String getValue() {
        return value;
    }
}
