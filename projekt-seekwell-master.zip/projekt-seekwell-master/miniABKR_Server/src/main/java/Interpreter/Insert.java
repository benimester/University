package Interpreter;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Insert implements Command {
    private String name;
    private final ArrayList<String> attributes;
    private final ArrayList<String> values;

    public Insert() {
        attributes = new ArrayList<>(0);
        values = new ArrayList<>(0);
    }

    public Insert(String name) {
        this.name = name;
        attributes = new ArrayList<>(0);
        values = new ArrayList<>(0);
    }

    /**
     * Returns the command type as a String
     *
     * @return command type
     */
    @Override
    public String getType() {
        return "INSERT INTO";
    }

    /**
     * Returns the provided table name
     *
     * @return table name
     */
    @Override
    public String getName() {
        return name;
    }

    public static Insert check(String expr) {
        Pattern insertRegex = Pattern.compile("^INSERT INTO [a-z][a-z0-9_]*\\s*\\(.+\\)\\s*VALUES\\s*\\(.+\\)$", Pattern.CASE_INSENSITIVE);
        Pattern tablesRegex = Pattern.compile("^[a-z][a-z0-9_]*(,\\s*[a-z][a-z0-9_]*)*$", Pattern.CASE_INSENSITIVE);
        Pattern valuesRegex = Pattern.compile("^[a-z0-9][a-z0-9_.,\\-]*(,\\s*[a-z0-9][a-z0-9_.,\\-]*)*$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = insertRegex.matcher(expr);
        if (!matcher.find()) {
            return null;
        }
        String tables = expr.substring(expr.indexOf("(") + 1, expr.indexOf("VALUES") - 2).replace(" ", "");
        matcher = tablesRegex.matcher(tables);
        if (!matcher.find()) {
            return null;
        }
        String values = expr.replace(" ", "").substring(expr.replace(" ", "").indexOf("VALUES") + 7, expr.replace(" ", "").lastIndexOf(')'));
        matcher = valuesRegex.matcher(values);
        if (!matcher.find()) {
            return null;
        }
        String[] tableTokens = tables.split(",");
        String[] valueTokens = values.split(",");
        if (tableTokens.length != valueTokens.length) {
            return null;
        }

        Insert insert = new Insert(expr.replace(" ", "").substring(10, expr.replace(" ", "").indexOf("(")));

        for (int i = 0; i < tableTokens.length; ++i) {
            insert.addPair(tableTokens[i].replace(" ", ""), valueTokens[i].replace(" ", ""));
        }
        return insert;
    }

    private void addPair(String attr, String value) {
        attributes.add(attr);
        values.add(value);
    }

    public ArrayList<String> getAttributes() {
        return attributes;
    }

    public ArrayList<String> getValues() {
        return values;
    }
}
