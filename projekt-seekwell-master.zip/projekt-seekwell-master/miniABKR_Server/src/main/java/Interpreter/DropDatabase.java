package Interpreter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DropDatabase implements Command {
    String name;

    public DropDatabase() {
    }

    public DropDatabase(String name) {
        this.name = name;
    }

    /**
     * Returns the command type as a String
     *
     * @return command type
     */
    @Override
    public String getType() {
        return "DROP DATABASE";
    }

    /**
     * Returns the provided database name
     *
     * @return database name
     */
    @Override
    public String getName() {
        return name;
    }

    public static DropDatabase check(String expr) {
        Pattern createDb = Pattern.compile("^DROP DATABASE [a-z][a-z0-9_]+$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = createDb.matcher(expr);
        if (!matcher.find()) {
            return null;
        }
        return new DropDatabase(expr.split(" ")[2].toLowerCase());
    }
}
