package Interpreter;

public class Invalid implements Command {

    private String name;

    public Invalid(String expr) {
        this.name = expr;
    }

    @Override
    public String getType() {
        return "INVALID";
    }

    /**
     * Returns the invalid command
     *
     * @return command
     */
    @Override
    public String getName() {
        return name;
    }
}
