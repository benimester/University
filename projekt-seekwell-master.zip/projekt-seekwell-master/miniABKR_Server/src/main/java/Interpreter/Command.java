package Interpreter;

public interface Command {
    public String getType();

    public String getName();
}
