package Interpreter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DropTable implements Command {
    String name;

    public DropTable() {
    }

    public DropTable(String name) {
        this.name = name;
    }

    /**
     * Returns the command type as a String
     *
     * @return command type
     */
    @Override
    public String getType() {
        return "DROP TABLE";
    }

    /**
     * Returns the provided table name
     *
     * @return table name
     */
    @Override
    public String getName() {
        return name;
    }

    public static DropTable check(String expr) {
        Pattern dropTable = Pattern.compile("^DROP TABLE [a-z][a-z0-9_]*$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = dropTable.matcher(expr);
        if (!matcher.find()) {
            return null;
        }
        return new DropTable(expr.split(" ")[2]);
    }
}
