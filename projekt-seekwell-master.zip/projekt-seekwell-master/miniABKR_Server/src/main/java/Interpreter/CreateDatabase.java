package Interpreter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateDatabase implements Command {

    private String name;

    public CreateDatabase() {
    }

    public CreateDatabase(String name) {
        this.name = name;
    }

    /**
     * Returns the command type as a String
     *
     * @return command type
     */
    @Override
    public String getType() {
        return "CREATE DATABASE";
    }

    /**
     * Returns the provided database name
     *
     * @return database name
     */
    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static CreateDatabase check(String expr) {
        Pattern createDb = Pattern.compile("^CREATE DATABASE [a-z][a-z0-9_]*$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = createDb.matcher(expr);
        if (!matcher.find()) {
            return null;
        }
        return new CreateDatabase(expr.split(" ")[2].toLowerCase());
    }


}
