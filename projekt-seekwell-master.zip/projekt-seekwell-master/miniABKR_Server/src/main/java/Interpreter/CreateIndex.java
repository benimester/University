package Interpreter;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateIndex implements Command {
    String name;
    ArrayList<String> attributeName;
    ArrayList<String> attributeModifier;

    public CreateIndex() {
        attributeName = new ArrayList<>(0);
        attributeModifier = new ArrayList<>(0);
    }

    public CreateIndex(String name) {
        this.name = name;
        attributeName = new ArrayList<>(0);
        attributeModifier = new ArrayList<>(0);
    }

    /**
     * Returns the command type as a String
     *
     * @return command type
     */
    @Override
    public String getType() {
        return "CREATE INDEX";
    }


    /**
     * Returns the provided index name
     *
     * @return index name
     */
    @Override
    public String getName() {
        return name;
    }

    public static CreateIndex check(String expr) {
        Pattern createIndex = Pattern.compile("^CREATE INDEX [a-z][a-z0-9_]* ON .+$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = createIndex.matcher(expr);
        if (!matcher.find()) {
            return null;
        }

        CreateIndex index = new CreateIndex(expr.substring(13, expr.indexOf(" ON")) + " " + (expr.substring(expr.indexOf("ON ") + 3, expr.indexOf('('))).replace(" ", ""));
        String attr = expr.substring(expr.indexOf('(') + 1, expr.lastIndexOf(')'));
        String[] tokens = attr.split(", ");
        Pattern simpleAttr = Pattern.compile("^[a-z][a-z0-9_]*( DESC| ASC)?$", Pattern.CASE_INSENSITIVE);
        for (String t : tokens) {
            Matcher m = simpleAttr.matcher(t);
            if (m.find()) {
                try {
                    index.addAttribute(t.split(" ")[1], t.split(" ")[0]);
                } catch (Exception e) {
                    index.addAttribute("", t.split(" ")[0]);
                }
            }
        }
        return index;
    }

    public void addAttribute(String type, String name) {
        attributeModifier.add(type);
        attributeName.add(name);
    }

    public ArrayList<String> getAttributeName() {
        return attributeName;
    }

    public ArrayList<String> getAttributeModifier() {
        return attributeModifier;
    }
}
