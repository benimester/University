package Interpreter;

import java.util.ArrayList;

public class Interpreter {

    public Interpreter() {
    }

    /**
     * Returns an interpreted command
     *
     * @return Interpreter.Command object
     */
    public ArrayList<Command> interpret(String rawInput) {
        ArrayList<Command> interpreted = new ArrayList<>(0);

        rawInput = rawInput.replace("\n", "");
        rawInput = rawInput.replace("\t", "");
        rawInput = rawInput.replaceAll("\\s+", " ");

        String[] commands = rawInput.split(";");
        for (String c : commands) {
            Command result = null;
            result = CreateDatabase.check(c);
            if (result != null) {
                System.out.println("MATCH: " + result.getType());
                interpreted.add(result);
                continue;
            }
            result = CreateTable.check(c);
            if (result != null) {
                System.out.println("MATCH: " + result.getType());
                interpreted.add(result);
                continue;
            }
            result = DropDatabase.check(c);
            if (result != null) {
                System.out.println("MATCH: " + result.getType());
                interpreted.add(result);
                continue;
            }
            result = DropTable.check(c);
            if (result != null) {
                System.out.println("MATCH: " + result.getType());
                interpreted.add(result);
                continue;
            }
            result = Use.check(c);
            if (result != null) {
                System.out.println("MATCH: " + result.getType());
                interpreted.add(result);
                continue;
            }
            result = CreateIndex.check(c);
            if (result != null) {
                System.out.println("MATCH: " + result.getType());
                interpreted.add(result);
                continue;
            }
            result = Insert.check(c);
            if (result != null) {
                System.out.println("MATCH: " + result.getType());
                interpreted.add(result);
                continue;
            }

            result = Delete.check(c);
            if (result != null) {
                System.out.println("MATCH: " + result.getType());
                interpreted.add(result);
                continue;
            }

            result = new Invalid(c);
            System.out.println("No match for: " + "\'" + c + "\'");
        }
        return interpreted;
    }

}
