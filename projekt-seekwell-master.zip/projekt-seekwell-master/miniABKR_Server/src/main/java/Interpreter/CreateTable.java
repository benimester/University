package Interpreter;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateTable implements Command {
    private String name;
    ArrayList<String> attributeName;
    ArrayList<String> attributeType;
    ArrayList<String> refTable;
    ArrayList<String> refAttr;

    public CreateTable() {
        attributeName = new ArrayList<>(0);
        attributeType = new ArrayList<>(0);
        refTable = new ArrayList<>(0);
        refAttr = new ArrayList<>(0);
    }

    public CreateTable(String name) {
        this.name = name;
        attributeName = new ArrayList<>(0);
        attributeType = new ArrayList<>(0);
        refTable = new ArrayList<>(0);
        refAttr = new ArrayList<>(0);
    }

    /**
     * Returns the command type as a String
     *
     * @return command type
     */
    @Override
    public String getType() {
        return "CREATE TABLE";
    }

    /**
     * Returns the provided table name
     *
     * @return table name
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * Returns all the provided attribute names
     *
     * @return ArrayList of names
     */
    public ArrayList<String> getAttributeName() {
        return attributeName;
    }

    /**
     * Returns all the provided attribute types
     *
     * @return ArrayList of types
     */
    public ArrayList<String> getAttributeType() {
        return attributeType;
    }

    public ArrayList<String> getRefTable() {
        return refTable;
    }

    public ArrayList<String> getRefAttr() {
        return refAttr;
    }


    public void addAttribute(String type, String name, String refTable, String refAttr) {
        attributeType.add(type);
        attributeName.add(name);
        this.refTable.add(refTable);
        this.refAttr.add(refAttr);
    }

    public static CreateTable check(String expr) {
        Pattern createTable = Pattern.compile("^CREATE TABLE [a-z][a-z0-9_]*\\s*\\(.+\\)$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = createTable.matcher(expr);
        if (!matcher.find()) {
            return null;
        }

        CreateTable table = new CreateTable((expr.substring(13, expr.indexOf('('))).replace(" ", ""));
        String attr = expr.substring(expr.indexOf('(') + 1, expr.lastIndexOf(')'));

        String[] tokens = attr.split(",\\s*");
        Pattern simpleAttr = Pattern.compile("^[a-z][a-z0-9_]+ (INT|FLOAT|BIT|DATE|DATETIME|VARCHAR\\([1-9][0-9]{0,3}\\))( PRIMARY KEY)?( NOT NULL)?$", Pattern.CASE_INSENSITIVE);
        Pattern constraintFK = Pattern.compile("^CONSTRAINT [a-z][a-z0-9_]* FOREIGN KEY \\([a-z][a-z0-9_]*\\) REFERENCES [a-z][a-z0-9_]*\\([a-z][a-z0-9_]*\\)$", Pattern.CASE_INSENSITIVE);
        Pattern constraintPK = Pattern.compile("^CONSTRAINT [a-z][a-z0-9_]* PRIMARY KEY \\([a-z][a-z0-9_]*( [a-z][a-z0-9_]*){0,2}\\)$", Pattern.CASE_INSENSITIVE);
        for (String t : tokens) {
            Matcher m = constraintPK.matcher(t);
            // addAttribute(String type, String name, String refTable, String refAttr)
            if (m.find()) {
                table.addAttribute("PRIMARY KEY", t.split(" ")[1], "", t.substring(t.indexOf('(') + 1, t.lastIndexOf(')')));
                continue;
            }
            m = constraintFK.matcher(t);
            if (m.find()) {
                table.addAttribute("FOREIGN KEY", t.split(" ")[1] + " " + t.substring(t.indexOf('(') + 1, t.indexOf(')')), t.split(" ")[6].substring(0, t.split(" ")[6].indexOf('(')), t.split(" ")[6].substring(t.split(" ")[6].indexOf('(') + 1, t.split(" ")[6].indexOf(')')));
                continue;
            }
            m = simpleAttr.matcher(t);
            if (m.find()) {
                table.addAttribute(t.split(" ")[1], t.split(" ")[0], "", "");
                if (t.contains("PRIMARY KEY")) {
                    table.addAttribute("PRIMARY KEY", "PK" + t.split(" ")[0], "", t.split(" ")[0]);
                }
            }
        }
        return table;
    }
}
