package Interpreter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Use implements Command {

    private String name;

    public Use() {
    }

    public Use(String name) {
        this.name = name;
    }

    /**
     * Returns the command type as a String
     *
     * @return command type
     */
    @Override
    public String getType() {
        return "USE";
    }

    /**
     * Returns the provided database name
     *
     * @return database name
     */
    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static Use check(String expr) {
        Pattern createDb = Pattern.compile("^USE [a-z][a-z0-9_]*$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = createDb.matcher(expr);
        if (!matcher.find()) {
            return null;
        }
        return new Use(expr.split(" ")[1].toLowerCase());
    }
}
