package Server;

import Interpreter.*;
import Server.DataStructures.Attribute;
import Server.DataStructures.Database;
import Server.DataStructures.Index;
import Server.DataStructures.Table;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Server extends Thread {
    private boolean running;
    private final Interpreter interpreter;
    private MongoManager mongoManager;
    private final HashMap<String, Database> dbs;
    private List<Index> indexes;
    private String activeDb;
    private File indexFile;

    public Server() {
        super();
        running = true;
        interpreter = new Interpreter();
        try {
            mongoManager = new MongoManager();
        } catch (Exception e) {
            System.out.println("Error");
        }
        dbs = new HashMap<>();
        indexes = new ArrayList<>(0);
        activeDb = "master";
        loadData();
    }

    /**
     * Script execution function
     */
    public String scriptReceived(String script) {
        ArrayList<Command> commands = interpreter.interpret(script);
        boolean errorOccurred = false;
        //String exitMessage = "";
        StringBuilder exitMessage = new StringBuilder();
        String path = "miniABKR_Server/src/main/java/Data/";
        for (Command cmd : commands) {
            switch (cmd.getType()) {

                case "CREATE DATABASE":
                    if (!dbs.containsKey(cmd.getName().toLowerCase())) {
                        Database db = new Database(cmd.getName().toLowerCase());
                        dbs.put(cmd.getName().toLowerCase(), db);
                        ObjectMapper objectMapper = new ObjectMapper();
                        try {
                            File outputFile = new File(path + cmd.getName().toLowerCase() + ".json");
                            objectMapper.writeValue(outputFile, db);
                            String mongoOutputCreateDb = mongoManager.createDatabase(cmd.getName().toLowerCase());
                            if (mongoOutputCreateDb.contains("Error")) {
                                exitMessage.append(mongoOutputCreateDb).append("After this, please solve the inconsistency\n");
                                errorOccurred = true;

                            } else {
                                exitMessage.append("Database '").append(cmd.getName().toLowerCase()).append("' successfully created\n");
                            }
                        } catch (IOException e) {
                            exitMessage.append("Error: Could not create json file\n");
                            errorOccurred = true;
                        }
                    } else {
                        exitMessage.append("Error: The '").append(cmd.getName().toLowerCase()).append("' database already exists\n");
                        errorOccurred = true;
                    }
                    break;

                case "DROP DATABASE":
                    if (!dbs.containsKey(cmd.getName().toLowerCase())) {
                        exitMessage.append("Database '").append(cmd.getName().toLowerCase()).append("' does not exists; could not drop\n");
                        errorOccurred = true;
                    }
                    dbs.remove(cmd.getName().toLowerCase());

                    if (!(new File(path + cmd.getName().toLowerCase() + ".json")).delete()) {
                        exitMessage.append("Error: Could not delete json file\n");
                        errorOccurred = true;
                    }
                    String mongoOutputDropDb = mongoManager.dropDatabase(cmd.getName().toLowerCase());
                    if (mongoOutputDropDb.contains("Error")) {
                        exitMessage.append(mongoOutputDropDb).append("After this, please solve the inconsistency\n");
                        errorOccurred = true;
                    } else {
                        exitMessage.append("Database '").append(cmd.getName().toLowerCase()).append("' dropped\n");
                    }
                    break;

                case "CREATE TABLE":
                    ArrayList<Table> tables = (ArrayList<Table>) dbs.get(activeDb).getTables();
                    boolean contains = false;
                    for (Table t : tables) {
                        if (t.getName().equals(cmd.getName().toLowerCase())) {
                            contains = true;
                            break;
                        }
                    }
                    if (!contains) {
                        Table table = new Table(cmd.getName().toLowerCase());
                        CreateTable t = (CreateTable) cmd;
                        ArrayList<String> attrName = t.getAttributeName();
                        ArrayList<String> attrType = t.getAttributeType();
                        ArrayList<String> refTable = t.getRefTable();
                        ArrayList<String> refAttr = t.getRefAttr();
                        for (int i = 0; i < attrName.size(); ++i) {
                            switch (attrType.get(i)) {
                                case "PRIMARY KEY":
                                    boolean PKexists;
                                    String[] fields = refAttr.get(i).toLowerCase().split(" ");

                                    for (String field : fields) {
                                        PKexists = false;
                                        for (Attribute attribute : table.getAttributes()) {
                                            if (attribute.getName().equals(field)) {
                                                PKexists = true;
                                                attribute.setPK(attrName.get(i).toLowerCase());
                                            }
                                        }
                                        if (!PKexists) {
                                            exitMessage.append("Error: ").append(field).append(" doesn't exists!\n");
                                            errorOccurred = true;
                                            break;
                                        }
                                    }
                                    break;

                                case "FOREIGN KEY":
                                    String srcName = attrName.get(i).toLowerCase().split(" ")[1];

                                    boolean FKexists = false;
                                    for (Attribute attribute : table.getAttributes()) {
                                        if (attribute.getName().equals(srcName)) {
                                            FKexists = true;
                                            attribute.setFK(attrName.get(i).split(" ")[0]);
                                            attribute.setRefCol(refAttr.get(i));
                                            attribute.setRefTable(refTable.get(i));
                                        }
                                    }
                                    if (!FKexists) {
                                        exitMessage.append("Error: ").append(srcName).append(" doesn't exists!\n");
                                        errorOccurred = true;
                                        break;
                                    }
                                    break;

                                default:
                                    table.getAttributes().add(new Attribute(attrName.get(i).toLowerCase(), "", "", attrType.get(i).toUpperCase(), "", "", false, ""));
                            }
                        }

                        dbs.get(activeDb).getTables().add(table);
                        ObjectMapper objectMapper = new ObjectMapper();
                        try {
                            objectMapper.writeValue(new File(path + activeDb + ".json"), dbs.get(activeDb));
                            String mongoOutputCreateTb = mongoManager.createTable(activeDb, cmd.getName().toLowerCase());
                            if (mongoOutputCreateTb.contains("Error")) {
                                exitMessage.append(mongoOutputCreateTb).append("After this, please solve the inconsistency\n");
                                errorOccurred = true;
                            } else {
                                exitMessage.append("Table '").append(cmd.getName().toLowerCase()).append("' successfully created\n");
                            }
                        } catch (Exception ex) {
                            exitMessage.append("Error: Could not not write modifications to json file\n");
                            errorOccurred = true;
                        }
                    } else {
                        exitMessage.append("Error: Table '").append(cmd.getName().toLowerCase()).append("' does already exist in database ").append(activeDb).append("\n");
                        errorOccurred = true;
                    }
                    break;

                case "DROP TABLE":
                    ArrayList<Table> tb = (ArrayList<Table>) dbs.get(activeDb).getTables();
                    boolean containsTable = false;
                    for (Table t : tb) {
                        if (t.getName().equals(cmd.getName().toLowerCase())) {
                            containsTable = true;
                            break;
                        }
                    }
                    if (containsTable) {
                        tb.removeIf(table -> table.getName().equals(cmd.getName().toLowerCase()));

                        ObjectMapper objectMapper = new ObjectMapper();
                        try {
                            // Write the modified database structure back to the JSON file
                            objectMapper.writeValue(new File(path + activeDb + ".json"), dbs.get(activeDb));
                            String mongoOutputDropTb = mongoManager.dropTable(activeDb, cmd.getName().toLowerCase());
                            if (mongoOutputDropTb.contains("Error")) {
                                exitMessage.append(mongoOutputDropTb).append("After this, please solve the inconsistency\n");
                                errorOccurred = true;
                            } else {
                                exitMessage.append("Table '").append(cmd.getName().toLowerCase()).append("' successfully dropped\n");
                            }
                        } catch (IOException ex) {
                            exitMessage.append("Error: Could not write modifications to JSON file\n");
                            errorOccurred = true;
                        }
                    } else {
                        exitMessage.append("Error: Table '").append(cmd.getName().toLowerCase()).append("' does not exists in database ").append(activeDb).append("\n");
                        errorOccurred = true;
                    }
                    break;

                case "CREATE INDEX":
                    CreateIndex i = (CreateIndex) cmd;
                    Table refTable = null;
                    for (Table table : dbs.get(activeDb).getTables()) {
                        if (table.getName().equals(i.getName().split(" ")[1])) {
                            refTable = table;
                            break;
                        }
                    }

                    List<String> refAttr = new ArrayList<>(0);
                    assert refTable != null;
                    for (Attribute attribute : refTable.getAttributes()) {
                        for (String attrName : i.getAttributeName()) {
                            if (attribute.getName().equals(attrName)) {
                                refAttr.add(attribute.getName());
                            }
                        }
                    }

                    indexes.add(new Index(i.getName().split(" ")[0].toLowerCase(), refTable.getName(), refAttr, activeDb, i.getAttributeModifier()));

                    ObjectMapper objectMapper = new ObjectMapper();
                    try {
                        objectMapper.writeValue(indexFile, indexes);
                        exitMessage.append("Index '").append(i.getName().split(" ")[0]).append("' successfully created\n");
                    } catch (Exception ex) {
                        exitMessage.append("Error: Could not not write modifications to json file\n");
                        errorOccurred = true;
                    }

                    for (Index ind : indexes) {
                        System.out.println(ind.getName());
                    }

                    break;

                case "USE":
                    if (dbs.containsKey(cmd.getName().toLowerCase())) {
                        activeDb = cmd.getName().toLowerCase();
                        exitMessage.append("Using ").append(cmd.getName().toLowerCase()).append("\n");
                    } else {
                        activeDb = "master";
                        exitMessage.append("Error: Database " + "'").append(cmd.getName().toLowerCase()).append("'").append("does not exists\n");
                        errorOccurred = true;
                    }
                    break;

                case "INSERT INTO":
                    Insert insert = (Insert) cmd;
                    ArrayList<String> attr = insert.getAttributes();
                    ArrayList<String> values = insert.getValues();

                    StringBuilder id = new StringBuilder();
                    StringBuilder value = new StringBuilder();
                    Table table = dbs.get(activeDb).getTable(insert.getName().toLowerCase());
                    ArrayList<Attribute> attributes = (ArrayList<Attribute>) table.getAttributes();
                    int pkCount = 0;
                    for (Attribute attribute : attributes) {
                        int j = 0;
                        while (j < attr.size()) {
                            if (attribute.getName().equals(attr.get(j).toLowerCase())) {
                                if (!attribute.getPK().isEmpty()) {
                                    id.append(pkCount != 0 ? ";" : "").append(values.get(j));
                                    ++pkCount;
                                } else {
                                    value.append(values.get(j)).append(";");
                                }
                                break;
                            }
                            j++;
                        }
                        if (j == attr.size()) {
                            value.append("null;");
                        }
                    }
                    String mongoOutputInsert = mongoManager.insert(activeDb, table.getName(), id.toString(), value.toString());
                    if (mongoOutputInsert.contains("Error")) {
                        errorOccurred = true;
                    }
                    exitMessage.append(mongoOutputInsert);
                    break;

                case "DELETE":
                    Delete delete = (Delete) cmd;
                    String mongoOutputDelete = mongoManager.delete(activeDb, delete.getName().toLowerCase(), delete.getValue());
                    if (mongoOutputDelete.contains("Error")) {
                        errorOccurred = true;
                    }
                    exitMessage.append(mongoOutputDelete);
                    break;

                case "INVALID":
                    exitMessage.append("Error: Invalid statement: '").append(cmd.getName().toLowerCase()).append("'\n");
                    errorOccurred = true;
            }
            if (errorOccurred) {
                break;
            }
        }
        return exitMessage.toString();
    }

    /**
     * Everything here is executed before the Server thread runs
     */
    public void startServer() {
        super.start();
    }

    /**
     * Load databases from file
     */
    private void loadData() {
        File parentDirectory = new File("miniABKR_Server/src/main/java/Data");

        indexFile = new File("miniABKR_Server/src/main/java/Data/index.json");

        ObjectMapper objectMapper = new ObjectMapper();
        try {
            indexes = objectMapper.readValue(indexFile, new TypeReference<>() {
            });
        } catch (IOException ignored) {
        }

        File[] files = parentDirectory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith(".json") && !file.getName().equals("index.json")) {     // processing only json files
                    try {
                        Database database = objectMapper.readValue(file, Database.class);
                        dbs.put(database.getName(), database);
                    } catch (IOException ignored) {
                    }
                }
            }
        }
    }


    /**
     * This is what the Server thread does
     */
    @Override
    public void run() {
        super.run();
        System.out.println("The server is running");

        int serverPort = 8080;
        ServerSocket serverSocket;

        try {
            serverSocket = new ServerSocket(serverPort);
            serverSocket.setSoTimeout(5);
        } catch (Exception e) {
            System.out.println("[Server] Error: Could not initialize server");
            return;
        }
        System.out.println("The server is ready to receive");

        while (running) {
            Socket connectionSocket;
            try {
                connectionSocket = serverSocket.accept();
            } catch (Exception ex) {
                continue;
            }

            BufferedReader inFromClient;
            DataOutputStream outToClient;


            try {
                inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
                outToClient = new DataOutputStream(connectionSocket.getOutputStream());
            } catch (Exception ex) {
                System.out.println("[Server] Error: TCP communication error");
                return;
            }
            String sentence;
            StringBuilder receivedText = new StringBuilder();


            try {
                while ((sentence = inFromClient.readLine()) != null && !sentence.isEmpty()) {
                    receivedText.append(sentence);
                }
            } catch (IOException ex) {
                System.out.println("[Server] Error: TCP communication error");
                return;
            }

            String exitMessage;

            if (receivedText.toString().startsWith("GETDATABASETREE")) {
                System.out.println(receivedText);
                exitMessage = getClientTreeField(receivedText.toString());
            } else if (receivedText.toString().startsWith("GETVALUES")) {
                System.out.println(receivedText);
                getTableContent(outToClient, receivedText.toString());
                exitMessage = "";
            } else {
                exitMessage = scriptReceived(receivedText.toString());
                System.out.println(exitMessage);
            }

            if (!exitMessage.isEmpty()) {
                try {
                    outToClient.writeBytes(exitMessage);
                } catch (IOException ex) {
                    System.out.println("[Server] Error: TCP communication error");
                    return;
                }
            }


            try {
                connectionSocket.close();
            } catch (IOException e) {
                System.out.println("[Server] Error: Could not close the connection");
                return;
            }
        }
        try {
            serverSocket.close();
        } catch (IOException e) {
            System.out.println("[Server] Error: Could not close the socket");
            return;
        }
        System.out.println("[Server] The server is stopped");
    }

    public void stopServer() {
        running = false;
    }

    private String getClientTreeField(String task) {
        String[] fields = task.split(" ");
        String dataStructure = fields[1];

        File data = new File("miniABKR_Server/src/main/java/Data");
        String response = "GETDATABASETREE";
        ObjectMapper objectMapper = new ObjectMapper();
        switch (dataStructure) {
            case "Databases":
                for (File file : data.listFiles()) {
                    if (!file.getName().equals("index.json")) {
                        response += (" " + file.getName().split("\\.")[0]);
                    }
                }
                break;
            case "Tables":
                String dataB = fields[2];
                dataB += ".json";
                for (File file : data.listFiles()) {
                    if (file.getName().equals(dataB)) {
                        try {
                            Database database = objectMapper.readValue(file, Database.class);
                            for (Table table : database.getTables()) {
                                response += (" " + table.getName());
                            }
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                }

                break;
            case "Attributes":
                dataB = fields[2];
                dataB += ".json";
                String dataT = fields[3];
                for (File file : data.listFiles()) {
                    if (file.getName().equals(dataB)) {
                        try {
                            Database database = objectMapper.readValue(file, Database.class);
                            for (Table table : database.getTables()) {
                                if (table.getName().equals(dataT)) {
                                    for (Attribute attribute : table.getAttributes()) {
                                        response += (" " + attribute.getName());
                                    }
                                }
                            }
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                }
                System.out.println("The attributes: " + response);
                break;
            case "Type":
                dataB = fields[3].split(",")[0];
                dataB += ".json";
                dataT = fields[4].split(",")[0];
                String DataA = fields[5].split("]")[0];
                for (File file : data.listFiles()) {
                    if (file.getName().equals(dataB)) {
                        try {
                            Database database = objectMapper.readValue(file, Database.class);
                            for (Table table : database.getTables()) {
                                if (table.getName().equals(dataT)) {
                                    for (Attribute attribute : table.getAttributes()) {
                                        if (attribute.getName().equals(DataA)) {
                                            response += ("Name: " + attribute.getName());
                                            response += "\n";
                                            response += ("PK: " + attribute.getPK());
                                            response += "\n";
                                            response += ("FK: " + attribute.getFK());
                                            response += "\n";
                                            response += ("Type: " + attribute.getType());
                                            response += "\n";
                                            response += ("Index: " + attribute.getIndex());
                                            response += "\n";
                                            response += ("RefCol: " + attribute.getRefCol());
                                            response += "\n";
                                            response += ("RefTable: " + attribute.getRefTable());
                                        }
                                    }
                                }
                            }
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                }
                break;
        }
        return response;
    }


    private void getTableContent(DataOutputStream output, String text) {
        String refDatabase = text.split(" ")[1];
        String refTable = text.split(" ")[2];
        ArrayList<String> lines = mongoManager.getTableContent(refDatabase, refTable);
        Table t = dbs.get(refDatabase).getTable(refTable);

        StringBuilder headerLine = new StringBuilder();
        for (Attribute attribute : t.getAttributes()) {
            headerLine.append(attribute.getName()).append(";");
        }
        headerLine.append("\n");

        try {
            output.writeBytes(headerLine.toString());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        for (String line : lines) {
            try {
                output.writeBytes(line + "\n");
            } catch (IOException ex) {
                System.out.println("[Server] Error: TCP communication error");
            }
        }
        try {
            output.writeBytes("\n");    // closing the Value writing in the socket
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}