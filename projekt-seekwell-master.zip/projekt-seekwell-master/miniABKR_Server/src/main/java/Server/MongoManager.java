package Server;

import com.mongodb.client.*;
import org.bson.Document;

import java.util.ArrayList;

import static com.mongodb.client.model.Filters.eq;

public class MongoManager {
    private MongoClient mongoClient;

    public MongoManager() throws Exception {
        try {
            mongoClient = (MongoClient) MongoClients.create("mongodb://localhost:27017");
        } catch (Exception ex) {
            System.out.println("Cannot connect to mongodb://localhost:27017");
        }
    }

    public String createDatabase(String name) {
        try {
            mongoClient.getDatabase(name);
        } catch (Exception e) {
            return "[MongoDB] Error: Could not create database'\n";
        }
        return "[MongoDB] Database " + name + " created successfully\n";
    }

    public String dropDatabase(String name) {
        MongoDatabase db;
        try {
            db = mongoClient.getDatabase(name);
            db.drop();
        } catch (Exception e) {
            return "[MongoDB] Error: Could not drop database " + name + "\n";
        }
        return "Database " + name + " dropped successfully\n";
    }

    public String createTable(String databaseName, String tableName) {
        MongoDatabase db;
        try {
            db = mongoClient.getDatabase(databaseName);
            db.createCollection(tableName);
        } catch (Exception e) {
            return "[MongoDB] Error: Could not create table " + tableName + "\n";
        }
        return "Table created successfully\n";
    }

    public String dropTable(String databaseName, String tableName) {
        MongoDatabase db;
        MongoCollection<Document> collection;
        try {
            db = mongoClient.getDatabase(databaseName);
            collection = db.getCollection(tableName);
            collection.drop();
        } catch (Exception e) {
            return "[MongoDB] Error: Could not drop table " + tableName + "\n";
        }
        return "Table dropped successfully\n";
    }

    public String insert(String databaseName, String tableName, String primaryKey, String value) {
        MongoDatabase db;
        MongoCollection<Document> collection;
        try {
            db = mongoClient.getDatabase(databaseName);
            collection = db.getCollection(tableName);
            collection.insertOne(new Document("_id", primaryKey).append("value", value));
        } catch (Exception e) {
            return "[MongoDB] Error: Could not insert into " + tableName + "\n";
        }
        return "Value inserted successfully\n";
    }

    public String delete(String databaseName, String tableName, String primaryKey) {
        MongoDatabase db;
        MongoCollection<Document> collection;
        try {
            db = mongoClient.getDatabase(databaseName);
            collection = db.getCollection(tableName);
            collection.deleteOne(eq("_id", primaryKey));
        } catch (Exception e) {
            return "[MongoDB] Error: Could not delete from " + tableName + "\n";
        }
        return "Value deleted successfully\n";
    }

    public ArrayList<String> getTableContent(String databaseName, String tableName) {
        MongoDatabase db;
        MongoCollection<Document> collection;
        ArrayList<String> lines = new ArrayList<>(0);
        try {
            db = mongoClient.getDatabase(databaseName);
            collection = db.getCollection(tableName);
            MongoCursor<Document> cursor = collection.find().iterator();
            while (cursor.hasNext()) {
                Document d = cursor.next();
                lines.add(d.getString("_id") + ";" + d.getString("value"));
            }
            cursor.close();
        } catch (Exception e) {
            return null;
        }
        return lines;
    }
}
