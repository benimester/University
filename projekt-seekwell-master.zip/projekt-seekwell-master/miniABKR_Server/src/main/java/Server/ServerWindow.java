package Server;

import javax.swing.*;
import java.awt.*;

public class ServerWindow extends JFrame {
    Server server;

    public ServerWindow(Server server){
        this.server = server;

        setBounds(100, 100, 200, 100);

        setLayout(new FlowLayout());

        JButton startButton = new JButton("Start");
        startButton.addActionListener(e -> server.startServer());
        JButton stopButton = new JButton("Stop");
        stopButton.addActionListener(e -> server.stopServer());

        add(startButton);
        add(stopButton);

        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        Server server = new Server();
        new ServerWindow(server);
    }
}
