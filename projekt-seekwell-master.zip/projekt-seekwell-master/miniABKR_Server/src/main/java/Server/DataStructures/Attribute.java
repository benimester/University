package Server.DataStructures;

public class Attribute {
    private String name;
    private String PK;
    private String FK;
    private String type;
    private String refTable;
    private String refCol;
    private boolean unique;
    private String index;

    public Attribute() {
    }

    public Attribute(String name, String PK, String FK, String type, String refTable, String refCol, boolean unique, String index) {
        this.name = name;
        this.PK = PK;
        this.FK = FK;
        this.type = type;
        this.refTable = refTable;
        this.refCol = refCol;
        this.unique = unique;
        this.index = index;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPK() {
        return PK;
    }

    public void setPK(String PK) {
        this.PK = PK;
    }

    public String getFK() {
        return FK;
    }

    public void setFK(String FK) {
        this.FK = FK;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRefTable() {
        return refTable;
    }

    public void setRefTable(String refTable) {
        this.refTable = refTable;
    }

    public String getRefCol() {
        return refCol;
    }

    public void setRefCol(String refCol) {
        this.refCol = refCol;
    }

    public boolean isUnique() {
        return unique;
    }

    public void setUnique(boolean unique) {
        this.unique = unique;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }
}