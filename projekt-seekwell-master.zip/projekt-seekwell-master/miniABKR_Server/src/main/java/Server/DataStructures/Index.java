package Server.DataStructures;

import java.util.List;

public class Index {

    private String name;
    private String refTable;
    private List<String> refAttr;
    private String refDb;
    private List<String> type;

    public Index() {
    }

    public Index(String name, String refTable, List<String> refAttr, String refDb, List<String> type) {
        this.name = name;
        this.refTable = refTable;
        this.refAttr = refAttr;
        this.refDb = refDb;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefTable() {
        return refTable;
    }

    public void setRefTable(String refTable) {
        this.refTable = refTable;
    }

    public List<String> getRefAttr() {
        return refAttr;
    }

    public void setRefAttr(List<String> refAttr) {
        this.refAttr = refAttr;
    }

    public String getRefDb() {
        return refDb;
    }

    public void setRefDb(String refDb) {
        this.refDb = refDb;
    }

    public List<String> getType() {
        return type;
    }

    public void setType(List<String> type) {
        this.type = type;
    }
}
