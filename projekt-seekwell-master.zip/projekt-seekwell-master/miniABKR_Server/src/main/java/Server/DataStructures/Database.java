package Server.DataStructures;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class Database {
    private String name;
    private List<Table> tables;

    public Database() {
        tables = new ArrayList<Table>(0);
    }

    public String getName() {
        return name;
    }

    @JsonCreator
    public Database(@JsonProperty("name") String name) {
        this.name = name;
        tables = new ArrayList<Table>(0);
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Table> getTables() {
        return tables;
    }

    public Table getTable(String tableName) {
        for (Table t : tables) {
            if (t.getName().equals(tableName)) {
                return t;
            }
        }
        return null;
    }

    public void setTables(List<Table> tables) {
        this.tables = tables;
    }
}