package Server.DataStructures;

import java.util.ArrayList;
import java.util.List;

public class Table {
    private String name;
    private List<Attribute> attributes;

    public Table() {
    }

    public Table(String name) {
        this.name = name;
        attributes = new ArrayList<Attribute>(0);
    }

    public Table(String name, List<Attribute> attributes) {
        this.name = name;
        this.attributes = attributes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Attribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<Attribute> attributes) {
        this.attributes = attributes;
    }
}