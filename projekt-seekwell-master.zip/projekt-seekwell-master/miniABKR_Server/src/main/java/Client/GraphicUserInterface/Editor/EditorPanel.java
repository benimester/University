package Client.GraphicUserInterface.Editor;

import javax.swing.*;
import java.awt.*;

public class EditorPanel extends JPanel {
    private final JTextArea textArea;
    private JScrollPane scrollPane;

    /**
     * Creating the editor panel for editing the script
     */
    public EditorPanel() {
        this.setLayout(new BorderLayout());
        textArea = new JTextArea();
        textArea.setFont(new Font("Fira Code", 1, 20)); // Font.BOLD instead of 1
        textArea.setBackground(new Color(211, 211, 211));
        textArea.setForeground(new Color(0, 0, 0));
        textArea.setCaretColor(new Color(157, 157, 157));
        textArea.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); //padding
        textArea.setMargin(new Insets(10, 10, 10, 10)); // bekezdes
        textArea.setTabSize(3);

        scrollPane = new JScrollPane(textArea);
        this.add(scrollPane, BorderLayout.CENTER); // Add scrollPane instead of textArea
    }


    /**
     * Get the text-area's text
     * @return
     */
    public String getText(){
        return textArea.getText();
    }

    /**
     * Set the text-area's text
     * @param text
     */
    public void setText(String text){
        textArea.setText(text);
    }
}
