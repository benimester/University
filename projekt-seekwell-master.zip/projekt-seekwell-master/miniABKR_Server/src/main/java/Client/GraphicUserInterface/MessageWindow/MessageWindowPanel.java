package Client.GraphicUserInterface.MessageWindow;

import javax.swing.*;
import java.awt.*;

public class MessageWindowPanel extends JPanel {
    private final JTextArea textArea;
    private JLabel panelName;
    private JScrollPane scrollPane;

    /**
     * Creates the message window where will be displayed the message of server
     */
    public MessageWindowPanel() {
        this.setLayout(new BorderLayout());

        textArea = new JTextArea("Message");
        textArea.setFont(new Font("Fira Code", Font.BOLD, 20));
        textArea.setBackground(new Color(157, 157, 157));
        textArea.setForeground(new Color(0, 0, 0));
        textArea.setCaretColor(new Color(157, 157, 157));
        scrollPane = new JScrollPane(textArea);


        panelName = new JLabel("Message");
        panelName.setBackground(new Color(129, 129, 129));
        panelName.setForeground(new Color(0,0,0));
        this.add(panelName, BorderLayout.NORTH);
        this.add(scrollPane, BorderLayout.CENTER);
    }

    /**
     * Set the text of the textArea depending on the message gived (Error - red | otherwise - black)
     * @param message
     */
    public void setText(String message) {
        textArea.setText(message);

        if (message.contains("Error") || message.contains("ERROR") || message.contains("error")) {
            String newTextError = "";
            String newTextNotError = "";
            String oldText = textArea.getText();
            String[] fileds = oldText.split("\n");
            for (String field : fileds){
                if (field.contains("Error") || field.contains("error") || field.contains("ERROR")){
                    newTextError += field + "\n";
                }else{
                    newTextNotError += field + "\n";
                }
            }
            String newText = newTextError + newTextNotError;
            textArea.setText(newText);
            setTextColor(true);
        }else if (!message.contains("GETDATABASETREE")){
            setTextColor(false);
        }
    }

    /**
     * Set the text area's color (isError - true=> red | otherwise => black)
     * @param isError
     */
    private void setTextColor(boolean isError){
        if (isError){
            textArea.setForeground(new Color(236, 75, 75));
        }else {
            textArea.setForeground(new Color(0, 0, 0));
        }
    }

}
