package Client.GraphicUserInterface.DataExplorer;

import Client.GraphicUserInterface.GUI;
import Client.TCPClient.Connection;
import Client.TCPClient.ConnectionController;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Objects;

public class DataBaseWindowPanel extends JPanel {

    private GUI gui;
    private JLabel panelName;
    private static JTree databaseTree;
    private final String DIRECTORY_PATH = "miniABKR_Server/src/main/java/Data";
    private JScrollPane treeScrollPane;
    private PopupMenuDB popupMenuTables;
    private PopupMenuDB popupMenuAttributes;

    private HashMap <String,String[]> databases;
    private HashMap <String,String[]> tables;
    private HashMap <String,String[]> attributes;

    /**
     * Makes a JPanel for viewing all the databases stored in Data/
     */
    public DataBaseWindowPanel(GUI gui){
        this.gui = gui;

        panelName = new JLabel("Databases");
        popupMenuTables = new PopupMenuDB(this);

        CustomPanel edit = new CustomPanel("Edit values", popupMenuTables);

        popupMenuTables.add(edit);


        popupMenuAttributes = new PopupMenuDB(this);

        CustomPanel info = new CustomPanel("Info", popupMenuAttributes);

        popupMenuAttributes.add(info);

        // create the root node for the tree (there will be showed the databases)
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Databases");
        databaseTree = new JTree(root);
        databaseTree.expandRow(0);

        databaseTree.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                switch (e.getPath().getPathCount()) {
                    case 1:
                        //System.out.println("I want databases");
                        String response = sendToServer("GETDATABASETREE Databases");
                        if (response == null) {
                            break;
                        }
                        //System.out.println("1 " + response);
                        String[] fields = response.split(" ");
                        for (int i = 1; i < fields.length; i++) {
                            DefaultMutableTreeNode db = new DefaultMutableTreeNode(fields[i]);
                            if (!nodeExists(root, fields[i])) {
                                root.add(db);
                            }
                            //System.out.println(fields[i]);
                        }
                        break;

                    case 2:
                        //System.out.println("2 = " + e.getPath().toString().replace("\n", " "));
                        response = sendToServer("GETDATABASETREE Tables " + e.getPath().toString().replace("\n", " ").split(" ")[1].split("]")[0]);
                        if (response == null) {
                            break;
                        }
                        fields = response.split(" ");
                        DefaultMutableTreeNode databaseNode = findNode(root, e.getPath().toString().split(" ")[1].split("]")[0]);
                        if (databaseNode != null) {
                            for (int i = 1; i < fields.length; i++) {
                                DefaultMutableTreeNode tableNode = new DefaultMutableTreeNode(fields[i]);
                                if (!nodeExists(databaseNode, fields[i])) {
                                    databaseNode.add(tableNode);
                                }
                            }
                            ((DefaultTreeModel) databaseTree.getModel()).reload(databaseNode);
                            databaseTree.addMouseListener(new MouseAdapter() {
                                public void mousePressed(MouseEvent e) {
                                    if (SwingUtilities.isRightMouseButton(e)) {
                                        TreePath path = databaseTree.getPathForLocation(e.getX(), e.getY());
                                        if (path != null) {
                                            popupMenuTables.setRef(path.toString());
                                            int depth = path.getPathCount();
                                            if (depth == 3) { // Table node
                                                popupMenuTables.show(e.getComponent(), e.getX(), e.getY());
                                            }
                                        }
                                    }
                                }
                            });
                        }
                        break;

                    case 3:
                        String databaseName = e.getPath().getPathComponent(1).toString();
                        String tableName = e.getPath().getLastPathComponent().toString();
                        //System.out.println("I want attributes from database: " + databaseName + " and table: " + tableName);

                        response = sendToServer("GETDATABASETREE Attributes " + databaseName + " " + tableName);
                        if (response == null) {
                            break;
                        }
                        //System.out.println("3 " + response);

                        fields = response.split(" ");

                        databaseNode = findNode(root, databaseName);
                        if (databaseNode != null) {
                            DefaultMutableTreeNode tableNode = findNode(databaseNode, tableName);
                            if (tableNode != null) {
                                for (int i = 1; i < fields.length; i++) {
                                    if (!nodeExists(tableNode, fields[i])) {
                                        DefaultMutableTreeNode attributeNode = new DefaultMutableTreeNode(fields[i]);
                                        tableNode.add(attributeNode);
                                    }
                                }
                                ((DefaultTreeModel) databaseTree.getModel()).reload(tableNode);
                                databaseTree.addMouseListener(new MouseAdapter() {
                                    public void mousePressed(MouseEvent e) {
                                        if (SwingUtilities.isRightMouseButton(e)) {
                                            TreePath path = databaseTree.getPathForLocation(e.getX(), e.getY());
                                            if (path != null) {
                                                popupMenuAttributes.setRef(path.toString());
                                                int depth = path.getPathCount();
                                                if (depth == 4) { // Table node
                                                    popupMenuAttributes.show(e.getComponent(), e.getX(), e.getY());
                                                }
                                            }
                                        }
                                    }
                                });
                            }
                        }
                        break;
                }
            }
        });


        treeScrollPane = new JScrollPane(databaseTree);

        setLayout(new BorderLayout());
        add(panelName, BorderLayout.NORTH);
        add(treeScrollPane, BorderLayout.CENTER);
    }


    private String sendToServer(String text){
        Connection connection = new Connection("localhost", 8080, text, gui);
        ConnectionController connectionController = new ConnectionController(connection);
        Thread thread = new Thread(connectionController);
        thread.start();
        while (thread.isAlive()){
            ;
        }
        String response = connection.getResponse();
        if (response.contains("Server is not responding..")) {
            return null;
        }
        return response;
    }
    private DefaultMutableTreeNode findNode(DefaultMutableTreeNode root, String nodeName) {
        Enumeration<?> enumeration = root.depthFirstEnumeration();
        while (enumeration.hasMoreElements()) {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) enumeration.nextElement();
            if (nodeName.equals(node.getUserObject().toString())) {
                return node;
            }
        }
        return null;
    }
    private boolean nodeExists(DefaultMutableTreeNode parent, String nodeName) {
        for (int i = 0; i < parent.getChildCount(); i++) {
            DefaultMutableTreeNode childNode = (DefaultMutableTreeNode) parent.getChildAt(i);
            if (childNode.getUserObject().equals(nodeName)) {
                return true;
            }
        }
        return false;
    }

    public void refresh() {
        DefaultMutableTreeNode root = (DefaultMutableTreeNode) databaseTree.getModel().getRoot();
        root.removeAllChildren();
        ((DefaultTreeModel) databaseTree.getModel()).reload();

        databaseTree.revalidate();
        databaseTree.repaint();
    }

    public String getAttributesTypes(String pathToAttribute){
        return sendToServer("GETDATABASETREE Type " + pathToAttribute);
    }

    public void setInsertDeleteVisibleonGUI(){
        gui.setInsertDeletePanelVisible();
    }

    public void changeInsertDeletePanelGui(String refTable, String refDatabase){
        gui.setInsertDeletePanel(refTable, refDatabase);
    }
}
