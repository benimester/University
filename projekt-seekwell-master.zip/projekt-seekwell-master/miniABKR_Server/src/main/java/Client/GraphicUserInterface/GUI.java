package Client.GraphicUserInterface;

import Client.GraphicUserInterface.DataExplorer.DataBaseWindowPanel;
import Client.GraphicUserInterface.Editor.CardPanel;
import Client.GraphicUserInterface.Editor.EditorPanel;
import Client.GraphicUserInterface.Editor.InsertDeletePanel;
import Client.GraphicUserInterface.MessageWindow.MessageWindowPanel;
import Client.TCPClient.Connection;
import Client.TCPClient.ConnectionController;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;

public class GUI extends JFrame {
    private final EditorPanel editorPanel;    // editorPanel - ahova a scriptet irjuk
    private JButton runCodeButton;      // runCodeButton lenyomasanak hatasara a kliens elkuldi a servernek a scriptet
    private JButton refreshDatabases;
    private JButton exitButton;
    private JButton clearButton;
    private JButton jumpToEditorButton;
    private JMenuBar commandBar;
    private final DataBaseWindowPanel dataBaseWindowPanel;
    private final MessageWindowPanel messageWindowPanel;
    private InsertDeletePanel insertDeletePanel;
    private final CardPanel cardPanel;


    public GUI() {

        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            System.out.println("The mac-windows Gui not initialized");
        }


        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("SeekWell");
        this.setLayout(new BorderLayout());
        this.setBounds(100, 100, 1200, 800);


        messageWindowPanel = new MessageWindowPanel();
        messageWindowPanel.setPreferredSize(new Dimension(0, 150));

        editorPanel = new EditorPanel();
        String[] header = new String[]{"A", "B", "C"};
        insertDeletePanel = new InsertDeletePanel(0, "","");

        cardPanel = new CardPanel(editorPanel, insertDeletePanel);


        makeCommandBarWithButtons();


        dataBaseWindowPanel = new DataBaseWindowPanel(this);
        dataBaseWindowPanel.setPreferredSize(new Dimension(300, dataBaseWindowPanel.getPreferredSize().height));


        // menubar (kinyit uj fileokat, ment, torol, stb.)
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(89, 161, 248));


        JMenu fileMenu = new JMenu("File");

        JMenuItem openFile = new JMenuItem("Open");
        openFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY); // Only select files
                int result = fileChooser.showOpenDialog(GUI.this); // Show open dialog

                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();

                    try {
                        // Read the content of the file
                        StringBuilder content = new StringBuilder();
                        BufferedReader reader = new BufferedReader(new FileReader(selectedFile));
                        String line;
                        while ((line = reader.readLine()) != null) {
                            content.append(line).append("\n");
                        }
                        reader.close();

                        // Set the file content to the editorPanel
                        editorPanel.setText(content.toString());
                    } catch (IOException ex) {
                        ex.printStackTrace(); // Handle exception properly in your application
                    }
                }
            }
        });


        fileMenu.add(openFile);


        JMenuItem saveFile = new JMenuItem("Save");
        saveFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                int result = fileChooser.showSaveDialog(null);

                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();

                    // Ensure the file has a .txt extension
                    String filePath = selectedFile.getAbsolutePath();
                    if (!filePath.toLowerCase().endsWith(".txt")) {
                        selectedFile = new File(filePath + ".txt");
                    }

                    try (PrintWriter writer = new PrintWriter(selectedFile)) {
                        writer.print(editorPanel.getText());
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        fileMenu.add(saveFile);


        menuBar.add(fileMenu);


        this.setJMenuBar(menuBar);
        this.add(cardPanel, BorderLayout.CENTER);
        this.add(commandBar, BorderLayout.NORTH);
        this.add(dataBaseWindowPanel, BorderLayout.WEST);
        this.add(messageWindowPanel, BorderLayout.SOUTH);

        ((BorderLayout) getContentPane().getLayout()).setVgap(2); // Set vertical gap
        ((BorderLayout) getContentPane().getLayout()).setHgap(2); // Set horizontal gap
        this.setVisible(true);
    }


    private void sendToServer(String text) throws IOException {
        Connection connection = new Connection("localhost", 8080, text, this);
        ConnectionController connectionController = new ConnectionController(connection);
        Thread thread = new Thread(connectionController);
        thread.start();
    }

    private GUI getThis() {
        return this;
    }

    public void setMessageWindowPanelText(String text) {
        messageWindowPanel.setText(text);
    }

    public void setEditorPanelText(String text) {
        editorPanel.setText(text);
    }

    public void updateDatabaseWindowPanel() {
        dataBaseWindowPanel.refresh();
    }

    public void setInsertDeletePanelVisible() {
        cardPanel.showPanel("InsertDeletePanel");
    }

    private JButton makeButtonDesign(String name) {
        JButton button = new JButton(name);
        button.setBackground(new Color(7, 32, 63));
        button.setForeground(new Color(166, 166, 166));
        button.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        return button;
    }

    public void setInsertDeletePanel(String refTable, String refDatabase) {
        insertDeletePanel.setRefTable(refTable);
        insertDeletePanel.setRefDatabase(refDatabase);
        insertDeletePanel.clearTable();
        insertDeletePanel.revalidate();
        this.cardPanel.setInsertDeletePanel(insertDeletePanel);
        cardPanel.repaint();
    }

    private void makeCommandBarWithButtons(){
        // a runCode gomb letrehozasa
        runCodeButton = makeButtonDesign("Run Code");
        runCodeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                runCodeButton.setBackground(new Color(12, 64, 122));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                runCodeButton.setBackground(new Color(7, 32, 63));
            }
        });
        runCodeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    sendToServer(editorPanel.getText());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        exitButton = makeButtonDesign("Exit");
        exitButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                exitButton.setBackground(new Color(12, 64, 122));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                exitButton.setBackground(new Color(7, 32, 63));
            }
        });
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        refreshDatabases = makeButtonDesign("Refresh Databases");
        refreshDatabases.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateDatabaseWindowPanel();
            }
        });
        refreshDatabases.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                refreshDatabases.setBackground(new Color(12, 64, 122));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                refreshDatabases.setBackground(new Color(7, 32, 63));
            }
        });


        clearButton = makeButtonDesign("Clear Editor");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setEditorPanelText("");
            }
        });
        clearButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                clearButton.setBackground(new Color(12, 64, 122));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                clearButton.setBackground(new Color(7, 32, 63));
            }
        });


        jumpToEditorButton = makeButtonDesign("Jump to Editor Panel");
        jumpToEditorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardPanel.showPanel("EditorPanel");
            }
        });
        jumpToEditorButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                jumpToEditorButton.setBackground(new Color(12, 64, 122));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                jumpToEditorButton.setBackground(new Color(7, 32, 63));
            }
        });


        commandBar = new JMenuBar();
        commandBar.setOpaque(true);
        commandBar.setBackground(new Color(7, 32, 63));
        commandBar.setForeground(new Color(255, 255, 255));
        commandBar.setMargin(new Insets(0, 0, 0, 0));
        commandBar.add(runCodeButton);
        commandBar.add(exitButton);
        commandBar.add(refreshDatabases);
        commandBar.add(clearButton);
        commandBar.add(jumpToEditorButton);
    }

    public static void main(String[] args) {
        GUI gui = new GUI();
    }
}
