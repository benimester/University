package Client.GraphicUserInterface.DataExplorer;

import javax.swing.*;

public class PopupMenuDB extends JPopupMenu {
    private String ref;
    public DataBaseWindowPanel dataBaseWindowPanel;
    public PopupMenuDB(DataBaseWindowPanel dataBaseWindowPanel) {
        this.ref = null;
        this.dataBaseWindowPanel = dataBaseWindowPanel;
    }


    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public String getAttributesTypes(String pathToAttribute){
        return dataBaseWindowPanel.getAttributesTypes(pathToAttribute);
    }
}
