package Client.GraphicUserInterface.Editor;
import javax.swing.*;
import java.awt.*;

public class CardPanel extends JPanel {
    private EditorPanel editorPanel;
    private InsertDeletePanel insertDeletePanel;

    public CardPanel(EditorPanel editorPanel, InsertDeletePanel insertDeletePanel) {
        this.setLayout(new CardLayout());

        this.editorPanel = editorPanel;
        this.insertDeletePanel = insertDeletePanel;

        this.add(editorPanel, "EditorPanel");
        this.add(insertDeletePanel, "InsertDeletePanel");
    }


    public EditorPanel getEditorPanel() {
        return editorPanel;
    }

    public void setEditorPanel(EditorPanel editorPanel) {
        this.editorPanel = editorPanel;
    }

    public InsertDeletePanel getInsertDeletePanel() {
        return insertDeletePanel;
    }

    public void setInsertDeletePanel(InsertDeletePanel insertDeletePanel) {
        this.insertDeletePanel = insertDeletePanel;
    }

    public void showPanel(String panelref){
        CardLayout cardLayout = (CardLayout) this.getLayout();
        cardLayout.show(this, panelref);
    }
}
