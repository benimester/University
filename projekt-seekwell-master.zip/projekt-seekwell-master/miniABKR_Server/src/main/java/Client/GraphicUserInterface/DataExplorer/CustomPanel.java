package Client.GraphicUserInterface.DataExplorer;

import Client.GraphicUserInterface.Editor.InsertDeletePanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class CustomPanel extends JPanel {
    private String buttonText;
    private boolean hovered = false;
    private PopupMenuDB popupMenu;

    public CustomPanel(String text, PopupMenuDB popupMenu) {
        this.buttonText = text;
        this.popupMenu = popupMenu;
        setPreferredSize(new Dimension(150, 30));
        addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                hovered = true;
                repaint();
            }

            public void mouseExited(MouseEvent e) {
                hovered = false;
                repaint();
            }

            public void mousePressed(MouseEvent e) {
                if (buttonText.equals("Edit values")) {
                    String refTable = popupMenu.getRef().replace("\n", "").split(",")[2].split("]")[0].split(" ")[1];
                    String refDatabase = popupMenu.getRef().replace("\n", "").split(",")[1].replace(" ", "");

                    popupMenu.dataBaseWindowPanel.changeInsertDeletePanelGui(refTable, refDatabase);
                    popupMenu.dataBaseWindowPanel.setInsertDeleteVisibleonGUI();
                } else {
                    String answer = popupMenu.getAttributesTypes(popupMenu.getRef().replace("\n", ""));
                    answer = answer.substring(answer.indexOf(" "));
                    answer = answer.replaceAll("\n", "<br>");
                    JPopupMenu textPopup = new JPopupMenu();
                    JLabel textLabel = new JLabel("<html>" + answer + "</html>");
                    textPopup.add(textLabel);
                    textPopup.show(CustomPanel.this, e.getX(), e.getY());
                }
            }
        });
    }

    public PopupMenuDB getPopupMenu() {
        return popupMenu;
    }

    public void setPopupMenu(PopupMenuDB popupMenu) {
        this.popupMenu = popupMenu;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (hovered) {
            g.setColor(new Color(89, 161, 248));
            g.fillRect(0, 0, getWidth(), getHeight());
        }else{
            g.setColor(new Color(7, 32, 63));
            g.fillRect(0, 0, getWidth(), getHeight());
        }
        g.setColor(Color.WHITE);
        FontMetrics fm = g.getFontMetrics();
        int x = (getWidth() - fm.stringWidth(buttonText)) / 2;
        int y = ((getHeight() - fm.getHeight()) / 2) + fm.getAscent();
        g.drawString(buttonText, x, y);

    }
}
