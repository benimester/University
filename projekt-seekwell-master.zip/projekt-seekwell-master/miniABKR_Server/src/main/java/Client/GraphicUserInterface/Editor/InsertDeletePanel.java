package Client.GraphicUserInterface.Editor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class InsertDeletePanel extends JPanel {
    private JTable table;
    private JScrollPane scrollPane;
    private String refDatabase;
    private String refTable;
    private DefaultTableModel model;
    private String[] columnHeaders;

    public InsertDeletePanel(int initialRows, String refDatabase, String refTable) {

        this.refDatabase = refDatabase;
        this.refTable = refTable;
        columnHeaders = new String[]{"A", "B", "C"};
        model = new DefaultTableModel(initialRows, columnHeaders.length);
        model.setColumnIdentifiers(columnHeaders); // Set column headers
        this.setLayout(new BorderLayout());

        table = new JTable(model);

        scrollPane = new JScrollPane(table);
        table.setPreferredSize(new Dimension(800, 500));
        scrollPane.setPreferredSize(new Dimension(800, 500));
        this.setPreferredSize(new Dimension(800, 500));
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton addButton = new JButton("Add Data");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                insertRows();
            }
        });

        JButton deleteButton = new JButton("Delete Selected Row");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteSelectedRows();
            }
        });

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }


    public void addData(Object[] rowData) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.addRow(rowData);

        setScrollPanePreferredSize(model.getRowCount());
    }

    public void removeData(int rowIndex) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.removeRow(rowIndex);

        setScrollPanePreferredSize(model.getRowCount());
    }

    private void setScrollPanePreferredSize(int numRows) {
        Dimension preferredSize = table.getPreferredSize();
        preferredSize.height = numRows * table.getRowHeight();

        scrollPane.setPreferredSize(preferredSize);
    }


    /**
     * Deletes the selected row by client
     */
    private void deleteSelectedRows() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        int[] selectedRows = table.getSelectedRows();


        for (int i = selectedRows.length - 1; i >= 0; i--) {
            Object[] rowData = new Object[model.getColumnCount()];
            for (int j = 0; j < model.getColumnCount(); j++) {
                rowData[j] = model.getValueAt(selectedRows[i], j);
            }
            String deleteRows = "USE " + getRefDatabase() + ";\n" + "DELETE " + refTable + " WHERE " + columnHeaders[0] + " = " + rowData[0] + ";\n";
            System.out.println(deleteRows);
            sendToServer(deleteRows, true);
            model.removeRow(selectedRows[i]);
        }
    }

    /**
     * Inserts rows by given by client
     */
    private void insertRows(){
        String[] currentHeaders = columnHeaders;        // updating the column header

        String[] rowData = new String[currentHeaders.length];

        JPanel inputPanel = new JPanel(new GridLayout(currentHeaders.length, 2));

        for (int i = 0; i < currentHeaders.length; i++) {       // adding text fields to inserted inputs
            inputPanel.add(new JLabel(currentHeaders[i]));
            JTextField textField = new JTextField();
            inputPanel.add(textField);
        }

        int result = JOptionPane.showConfirmDialog(null, inputPanel, "Enter Data", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            for (int i = 0; i < currentHeaders.length; i++) {
                rowData[i] = ((JTextField) inputPanel.getComponent(i * 2 + 1)).getText(); // get text from text field
            }
            addData(rowData);       // adding it to tables
            String insertRows = "USE " + getRefDatabase() + ";\n";
            insertRows += "INSERT INTO " + getRefTable() + " (" + java.util.Arrays.toString(columnHeaders).split("\\[")[1].split("]")[0] + ")";
            insertRows += " VALUES (" + java.util.Arrays.toString(rowData).split("\\[")[1].split("]")[0] + ");\n";
            System.out.println(insertRows);
            sendToServer(insertRows, true);
        }
    }

    public String getRefDatabase() {
        return refDatabase;
    }

    public void setRefDatabase(String refDatabase) {
        this.refDatabase = refDatabase;
    }

    public String getRefTable() {
        return refTable;
    }

    public void setRefTable(String refTable) {
        this.refTable = refTable;
    }

    public void setColumnHeaders(String[] columnHeaders) {
        System.out.println("column header set");
        this.columnHeaders = columnHeaders;
    }

    /**
     * Updates the Table with the new selected Database and Table
     */
    public void clearTable() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Remove all rows from the table model

        sendToServer("GETVALUES " + refDatabase + " " + refTable, false);

        System.out.println("NEW\nRefTable: " + refTable + "\n" + "RefDatabase: " + refDatabase);
    }

    public String[] getColumnHeaders() {
        return columnHeaders;
    }


    /**
     * Connection class meant to manage the connection in insert and delete operations
     */
    class Connection {
        private final String serverName;
        private final int serverPort;
        private String sentText;
        private String responseText;
        private final boolean insertORdelete;

        public Connection(String serverName, int serverPort, String sentText, boolean insertORdelete) {
            this.serverPort = serverPort;
            this.serverName = serverName;
            this.sentText = sentText;
            this.insertORdelete = insertORdelete;
        }

        public String sendRecieveMessage() {
            try {
                Socket clientSocket = new Socket(serverName, serverPort);

                DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
                BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                sentText = sentText.replaceAll("\\n+", "\n");
                outToServer.writeBytes(sentText + '\n');
                outToServer.writeBytes("\n\n");

                StringBuilder modifiedText = new StringBuilder();
                String line = inFromServer.readLine();
                if (line != null) {
                    System.out.println(line);
                    if (!insertORdelete) {    // needed because of the two different sends: GETVALUE and INSERT OR DELETE
                        setColumnHeaders(line.split(";"));
                        model.setColumnCount(0);

                        for (String header : columnHeaders) {
                            model.addColumn(header);
                        }
                    }

                }


                while ((line = inFromServer.readLine()) != null && !line.isEmpty()) {
                    System.out.println(line);
                    String[] rowData = line.split(";");
                    if (!insertORdelete) {        // needed because of the two different sends: GETVALUE and INSERT OR DELETE
                        addData(rowData);
                    }
                    modifiedText.append(line).append("\n");
                }

                clientSocket.close();
                return modifiedText.toString();
            } catch (IOException e) {
                return "Error: Server is not responding..";
            }
        }

        public void setResponse(String response) {
            this.responseText = response;
        }

        public String getResponse() {
            return responseText;
        }
    }

    static class ConnectionController implements Runnable {
        private final Connection connection;

        public ConnectionController(Connection connection) {
            this.connection = connection;
        }

        @Override
        public void run() {
            String response = connection.sendRecieveMessage();
            connection.setResponse(response);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void sendToServer(String text, boolean insertORdelete) {
        Connection connection = new Connection("localhost", 8080, text, insertORdelete);
        ConnectionController controller = new ConnectionController(connection);
        Thread thread = new Thread(controller);
        thread.start();
        /*
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        */

        String response = connection.getResponse();
        System.out.println("sendToServer from insertPanel RESPONSE: " + response);
    }
}