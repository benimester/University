package Client.TCPClient;

import java.io.IOException;

public class ConnectionController implements Runnable{
    private Connection connection;

    public ConnectionController(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void run() {
        String response = connection.sendRecieveMessage();
        connection.setResponse(response);
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
