package Client.TCPClient;
import Client.GraphicUserInterface.GUI;

import java.io.*;
import java.net.*;

public class Connection{
    private String serverName;
    private int serverPort;
    private String sentText;
    private String responseText;
    private GUI gui;

    public Connection(String serverName, int serverPort, String sentText, GUI gui) {
        this.serverPort = serverPort;
        this.serverName = serverName;
        this.sentText = sentText;
        this.gui = gui;
    }

    public String sendRecieveMessage(){
        try{

            Socket clientSocket = new Socket(serverName, serverPort);

            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            // sending multiple lines to the server
            sentText = sentText.replaceAll("\\n+", "\n");
            outToServer.writeBytes(sentText + '\n');
            outToServer.writeBytes("\n\n");

            // receiving the modified text from the server
            StringBuilder modifiedText = new StringBuilder();
            String line;
            while ((line = inFromServer.readLine()) != null && !line.isEmpty()) {
                modifiedText.append(line + "\n");
            }

            clientSocket.close();
            return modifiedText.toString();
        }
        catch (IOException e){
            return "Error: Server is not responding..";
        }
    }

    public void setResponse(String response){
        if (response.contains("GETDATABASETREE")){
            this.responseText = response;
        }else {
            this.responseText = response;
            gui.setMessageWindowPanelText(response);
        }
    }

    public String getResponse() {
        return responseText;
    }
}